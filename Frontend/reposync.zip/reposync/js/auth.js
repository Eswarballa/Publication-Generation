class Auth {
  constructor() {
    this.isAuthenticated = false;
    this.user = null;
  }

  async login(email, password) {
    // Implement login logic
    try {
      // Simulate API call
      if (email && password) {
        this.isAuthenticated = true;
        this.user = {
          email,
          name: "Test User",
          institution: "IIT Kashmir",
        };
        return true;
      }
      return false;
    } catch (error) {
      console.error("Login error:", error);
      return false;
    }
  }

  async register(userData) {
    // Implement registration logic
    try {
      // Simulate API call
      if (userData) {
        return true;
      }
      return false;
    } catch (error) {
      console.error("Registration error:", error);
      return false;
    }
  }

  logout() {
    this.isAuthenticated = false;
    this.user = null;
    window.location.href = "/index.html";
  }

  isLoggedIn() {
    return this.isAuthenticated;
  }

  getCurrentUser() {
    return this.user;
  }
}

// Export for use in other files
window.Auth = new Auth();
