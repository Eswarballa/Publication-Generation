class RepoSyncAPI {
  constructor() {
    this.baseURL = "https://dblp.org/search/publ/api";
  }

  async fetchPublications(authorName) {
    try {
      const response = await fetch(
        `${this.baseURL}?q=author:${authorName}:&format=json`
      );
      const data = await response.json();
      return this.transformPublications(data);
    } catch (error) {
      console.error("Error fetching publications:", error);
      return [];
    }
  }

  transformPublications(data) {
    if (!data.result || !data.result.hits || !data.result.hits.hit) {
      return [];
    }

    return data.result.hits.hit.map((pub) => ({
      title: pub.info.title,
      authors: Array.isArray(pub.info.authors.author)
        ? pub.info.authors.author
        : [pub.info.authors.author],
      year: pub.info.year,
      type: pub.info.type,
      venue: pub.info.venue || "N/A",
      url: pub.info.url || "#",
    }));
  }

  async searchGoogleScholar(authorName) {
    // Implement Google Scholar API integration
    // Note: Will require SerpAPI key and implementation
  }
}

// Export for use in other files
window.RepoSyncAPI = RepoSyncAPI;
